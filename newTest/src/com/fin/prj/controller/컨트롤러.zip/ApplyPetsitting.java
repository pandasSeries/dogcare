package com.fin.prj.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomCollectionEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fin.prj.dao.IApplyPetsittingDAO;
import com.fin.prj.dao.IApplyPetsittingFormDAO;
import com.fin.prj.dto.ApplyPetsittingDTO;

@Controller
public class ApplyPetsitting
{
	@Autowired
	private SqlSession sqlSession;
	
	@InitBinder
    protected void initBinder(WebDataBinder binder) 
	{
        binder.registerCustomEditor(List.class, "dog", new CustomCollectionEditor(ArrayList.class));
        binder.registerCustomEditor(List.class, "req", new CustomCollectionEditor(ArrayList.class));
    }
	
	@RequestMapping(value="applypetsittingform.action", method=RequestMethod.GET)
	public String applyPetsittingForm(String memCd, Model model)
	{
		String result = "";
		
		IApplyPetsittingFormDAO dao = sqlSession.getMapper(IApplyPetsittingFormDAO.class);
		
		model.addAttribute("myDogList", dao.myDogList(memCd));
		model.addAttribute("memInfo", dao.searchMemInfo(memCd));
		model.addAttribute("reqList", dao.reqList());
		
		result = "/WEB-INF/view/ApplyPetsittingForm.jsp";
		
		return result;
	}
	
	@RequestMapping(value="applypetsitting.action", method=RequestMethod.POST)
	public String applyPetsitting(ApplyPetsittingDTO dto)
	{
		String result = "";
		
		IApplyPetsittingDAO dao = sqlSession.getMapper(IApplyPetsittingDAO.class);
		
		String memdog1 = null;
		String memdog2 = null;
		String memdog3 = null;
		
		ArrayList<String> dogList = dto.getDog();
		
		if (dogList != null) 
		{
	        if (dogList.size() > 0) 
	        {
	            memdog1 = dogList.get(0);
	        }
	        if (dogList.size() > 1) 
	        {
	            memdog2 = dogList.get(1);
	        }
	        if (dogList.size() > 2) 
	        {
	            memdog3 = dogList.get(2);
	        }
	    }
		
		dao.addDogList(memdog1, memdog2, memdog3);
		dao.addPetsittingReq(dao.searchListCd(memdog1), dto);
		
		if (dto.getReq() != null && !dto.getReq().isEmpty())
		{
			for (String req : dto.getReq())
			{
				dao.addReq(dao.searchPetsittingReqCd(dao.searchListCd(memdog1)), req);
			}				
		}
		
		result = "redirect:petsittinglist.action";
		
		return result;
	}
	
}
