package com.fin.prj.dto;

public class DogDTO
{
	String dog_cd, mem_cd, breed_cd, dog_name, dog_birth, dor_reg, dog_pass, foo_cd, acti_cd, siz_cd, breed;
	int dog_weight, age;
	
	
	public String getBreed()
	{
		return breed;
	}
	public void setBreed(String breed)
	{
		this.breed = breed;
	}
	public int getAge()
	{
		return age;
	}
	public void setAge(int age)
	{
		this.age = age;
	}
	public String getDog_cd()
	{
		return dog_cd;
	}
	public void setDog_cd(String dog_cd)
	{
		this.dog_cd = dog_cd;
	}
	public String getMem_cd()
	{
		return mem_cd;
	}
	public void setMem_cd(String mem_cd)
	{
		this.mem_cd = mem_cd;
	}
	public String getBreed_cd()
	{
		return breed_cd;
	}
	public void setBreed_cd(String breed_cd)
	{
		this.breed_cd = breed_cd;
	}
	public String getDog_name()
	{
		return dog_name;
	}
	public void setDog_name(String dog_name)
	{
		this.dog_name = dog_name;
	}
	public String getDog_birth()
	{
		return dog_birth;
	}
	public void setDog_birth(String dog_birth)
	{
		this.dog_birth = dog_birth;
	}
	public String getDor_reg()
	{
		return dor_reg;
	}
	public void setDor_reg(String dor_reg)
	{
		this.dor_reg = dor_reg;
	}
	public String getDog_pass()
	{
		return dog_pass;
	}
	public void setDog_pass(String dog_pass)
	{
		this.dog_pass = dog_pass;
	}
	public String getFoo_cd()
	{
		return foo_cd;
	}
	public void setFoo_cd(String foo_cd)
	{
		this.foo_cd = foo_cd;
	}
	public String getActi_cd()
	{
		return acti_cd;
	}
	public void setActi_cd(String acti_cd)
	{
		this.acti_cd = acti_cd;
	}
	public String getSiz_cd()
	{
		return siz_cd;
	}
	public void setSiz_cd(String siz_cd)
	{
		this.siz_cd = siz_cd;
	}
	public int getDog_weight()
	{
		return dog_weight;
	}
	public void setDog_weight(int dog_weight)
	{
		this.dog_weight = dog_weight;
	}
	
	
}
