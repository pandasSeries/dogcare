package com.fin.prj.dto;

import java.util.ArrayList;

public class ApplyPetsittingDTO
{
	private String memCd, zonecode, addr1, addr2, workDate, startTime, cf;
	//-- 회원코드, 우편번호, 도로명주소, 상세주소, 예약일자, 예약일시, 참고사항
	private int time;
	//-- 돌봄시간
	private ArrayList<String> dog;
	//-- 맡길 반려견 리스트
	private ArrayList<String> req;
	//-- 요청사항
	
	public String getZonecode()
	{
		return zonecode;
	}
	public void setZonecode(String zonecode)
	{
		this.zonecode = zonecode;
	}
	public String getAddr1()
	{
		return addr1;
	}
	public void setAddr1(String addr1)
	{
		this.addr1 = addr1;
	}
	public String getAddr2()
	{
		return addr2;
	}
	public void setAddr2(String addr2)
	{
		this.addr2 = addr2;
	}
	public String getWorkDate()
	{
		return workDate;
	}
	public void setWorkDate(String workDate)
	{
		this.workDate = workDate;
	}
	public String getStartTime()
	{
		return startTime;
	}
	public void setStartTime(String startTime)
	{
		this.startTime = startTime;
	}
	public String getCf()
	{
		return cf;
	}
	public void setCf(String cf)
	{
		this.cf = cf;
	}
	public int getTime()
	{
		return time;
	}
	public void setTime(int time)
	{
		this.time = time;
	}
	public ArrayList<String> getDog()
	{
		return dog;
	}
	public void setDog(ArrayList<String> dog)
	{
		this.dog = dog;
	}
	public ArrayList<String> getReq()
	{
		return req;
	}
	public void setReq(ArrayList<String> req)
	{
		this.req = req;
	}
}
