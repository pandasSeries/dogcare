package com.fin.prj.dto;

public class PetsitterInfoDTO
{
	private String s_cd, sitting_apply_cd, name, gender, gr, exp_yn;
	//-- 펫시터코드, 펫시팅지원코드, 이름, 성별, 등급, 반려경험유무
	private int age, h_pay, perform_count, perform_b_count, perform_m_count, perform_s_count;
	//-- 나이, 시급, 수행건수, 대형견 수행건수, 중형견 수행건수, 소형견 수행건수
	private double rating_avg;
	//-- 평균평점
	
	
	public int getPerform_b_count()
	{
		return perform_b_count;
	}
	public void setPerform_b_count(int perform_b_count)
	{
		this.perform_b_count = perform_b_count;
	}
	public int getPerform_m_count()
	{
		return perform_m_count;
	}
	public void setPerform_m_count(int perform_m_count)
	{
		this.perform_m_count = perform_m_count;
	}
	public int getPerform_s_count()
	{
		return perform_s_count;
	}
	public void setPerform_s_count(int perform_s_count)
	{
		this.perform_s_count = perform_s_count;
	}
	public String getSitting_apply_cd()
	{
		return sitting_apply_cd;
	}
	public void setSitting_apply_cd(String sitting_apply_cd)
	{
		this.sitting_apply_cd = sitting_apply_cd;
	}
	public String getExp_yn()
	{
		return exp_yn;
	}
	public void setExp_yn(String exp_yn)
	{
		this.exp_yn = exp_yn;
	}
	public String getS_cd()
	{
		return s_cd;
	}
	public void setS_cd(String s_cd)
	{
		this.s_cd = s_cd;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public int getAge()
	{
		return age;
	}
	public void setAge(int age)
	{
		this.age = age;
	}
	public String getGender()
	{
		return gender;
	}
	public void setGender(String gender)
	{
		this.gender = gender;
	}
	public String getGr()
	{
		return gr;
	}
	public void setGr(String gr)
	{
		this.gr = gr;
	}
	public int getH_pay()
	{
		return h_pay;
	}
	public void setH_pay(int h_pay)
	{
		this.h_pay = h_pay;
	}
	public int getPerform_count()
	{
		return perform_count;
	}
	public void setPerform_count(int perform_count)
	{
		this.perform_count = perform_count;
	}
	public double getRating_avg()
	{
		return rating_avg;
	}
	public void setRating_avg(double rating_avg)
	{
		this.rating_avg = rating_avg;
	}
}
