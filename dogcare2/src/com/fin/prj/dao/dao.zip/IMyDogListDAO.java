package com.fin.prj.dao;

import java.util.ArrayList;

import com.fin.prj.dto.MyDogListDTO;

public interface IMyDogListDAO
{
	public ArrayList<MyDogListDTO> list();
}
